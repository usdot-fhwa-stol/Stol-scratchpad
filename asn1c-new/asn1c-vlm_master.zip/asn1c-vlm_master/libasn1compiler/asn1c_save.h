#ifndef	ASN1C_SAVE_H
#define	ASN1C_SAVE_H

int asn1c_save_compiled_output(arg_t *arg, const char *datadir, const char* destdir,
	int argc, int optc, char **argv);

#endif	/* ASN1C_SAVE_H */
