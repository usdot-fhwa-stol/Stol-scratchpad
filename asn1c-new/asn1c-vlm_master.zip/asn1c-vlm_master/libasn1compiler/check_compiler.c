#include "asn1compiler.h"

int
main(int ac, char **av) {
	return 0;
}

