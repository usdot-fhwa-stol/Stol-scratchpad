#ifndef	ASN1FIX_DEREFV_H
#define	ASN1FIX_DEREFV_H

int asn1f_fix_dereference_values(arg_t *);

int asn1f_fix_dereference_defaults(arg_t *);

#endif	/* ASN1FIX_DEREFV_H */
